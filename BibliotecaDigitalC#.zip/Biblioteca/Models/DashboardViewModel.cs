﻿namespace Biblioteca.Models;

public class DashboardViewModel
{
    public int TotalUsuarios { get; set; }
    public int TotalLibros { get; set; }
    public int TotalPrestamos { get; set; }
    public int PrestamosActivos { get; set; }
}