﻿namespace Biblioteca.Models;
using System.ComponentModel.DataAnnotations;

public class Usuarios
{
    public int Id { get; set; }

    [Required, StringLength(150)]
    public string Nombre { get; set; }

    [Required, StringLength(50)]
    public string Documento { get; set; } // único

    [EmailAddress, StringLength(150)]
    public string Correo { get; set; }

    [StringLength(50)]
    public string Telefono { get; set; }

    public List<Prestamo> Prestamos { get; set; } = new();  
}