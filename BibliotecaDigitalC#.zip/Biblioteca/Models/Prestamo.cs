﻿namespace Biblioteca.Models;
using System.ComponentModel.DataAnnotations;

public class Prestamo
{
    public int Id { get; set; }

    [Required]
    public int UsuarioId { get; set; }
    public Usuarios Usuario { get; set; }

    [Required]
    public int LibroId { get; set; }
    public Libro Libro { get; set; }

    public DateTime FechaPrestamo { get; set; } = DateTime.UtcNow;

    public DateTime? FechaDevolucion { get; set; } // null = aún está prestado
}