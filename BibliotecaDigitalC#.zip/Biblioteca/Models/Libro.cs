﻿namespace Biblioteca.Models;
using System.ComponentModel.DataAnnotations;

public class Libro
{
    public int Id { get; set; }

    [Required(ErrorMessage = "El título es obligatorio"), StringLength(250)]
    public string Titulo { get; set; }

    [Required(ErrorMessage = "El autor es obligatorio") ,StringLength(150)]
    public string Autor { get; set; }

    [Required(ErrorMessage = "El código es obligatorio"), StringLength(100)]
    public string Codigo { get; set; } // único

    [Range(1, int.MaxValue, ErrorMessage = "Debe haber al menos un ejemplar disponible")]
    public int EjemplaresDisponibles { get; set; }

    public List<Prestamo> Prestamos { get; set; } = new();
}