﻿using Biblioteca.Data;
using Biblioteca.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore; 

namespace Biblioteca.Controllers;

public class BooksController : Controller
{
    private readonly BibliotecaContext _db;
    public BooksController(BibliotecaContext db) => _db = db;

    public IActionResult Index()
    {
        var libros = _db.Libros.ToList();
        return View(libros);
    }
    
    public IActionResult Create() => View();

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Create(Libro libro)
    {
        if (!ModelState.IsValid) return View(libro);

        if (_db.Libros.Any(l => l.Codigo == libro.Codigo))
        {
            ModelState.AddModelError(nameof(libro.Codigo), "Código ya registrado.");
            return View(libro);
        }
        
        try
        {
            _db.Libros.Add(libro);
            _db.SaveChanges();
            TempData["Success"] = "Libro registrado correctamente.";
            return RedirectToAction(nameof(Index));
        }
        catch (DbUpdateException)
        {
            ModelState.AddModelError("", "Error de base de datos al crear libro.");
            return View(libro);
        }
    }
    public IActionResult Details(int id)
    {
        var libro = _db.Libros
            .Include(l => l.Prestamos)
            .ThenInclude(p => p.Usuario)
            .SingleOrDefault(l => l.Id == id);
        if (libro == null) return NotFound();
        return View(libro);
    }
}