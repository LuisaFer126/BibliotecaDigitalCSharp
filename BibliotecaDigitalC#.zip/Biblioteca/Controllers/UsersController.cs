﻿using Biblioteca.Data;
using Biblioteca.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Biblioteca.Controllers;

public class UsersController : Controller
{
    private readonly BibliotecaContext _db;
    public UsersController(BibliotecaContext db) => _db = db;

    public IActionResult Index()
    {
        var usuarios = _db.Usuarios.ToList();
        return View(usuarios);
    }
    
    
    public IActionResult Create() => View();

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Create(Usuarios usuario)
    {
        if (!ModelState.IsValid) return View(usuario);

        if (_db.Usuarios.Any(u => u.Documento == usuario.Documento))
        {
            ModelState.AddModelError(nameof(usuario.Documento), "Documento ya registrado.");
            return View(usuario);
        }

        try
        {
            _db.Usuarios.Add(usuario);
            _db.SaveChanges();
            TempData["Success"] = "Usuario registrado correctamente.";
            return RedirectToAction(nameof(Index));
        }
        catch (DbUpdateException)
        {
            ModelState.AddModelError("", "Error de base de datos al crear usuario.");
            return View(usuario);
        }
    }

    public IActionResult Details(int id)
    {
        var user = _db.Usuarios
            .Include(u => u.Prestamos)
            .ThenInclude(p => p.Libro)
            .SingleOrDefault(u => u.Id == id);
        if (user == null)  return NotFound();
        return View(user);
    }
    
}