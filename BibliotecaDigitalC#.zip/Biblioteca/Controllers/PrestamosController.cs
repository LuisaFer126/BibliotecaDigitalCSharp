﻿using Biblioteca.Data;
using Biblioteca.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Biblioteca.Controllers;

public class PrestamosController : Controller
{
    private readonly BibliotecaContext _db;
    public PrestamosController(BibliotecaContext db) => _db = db;

    public IActionResult Index()
    {
        var prestamos = _db.Prestamos
            .Include(p => p.Usuario)
            .Include(p => p.Libro)
            .OrderByDescending(p => p.FechaPrestamo)
            .ToList();
        return View(prestamos);
    }

    public IActionResult Create()
     {
            ViewBag.Usuarios = _db.Usuarios.ToList();
            ViewBag.Libros = _db.Libros.Where(l => l.EjemplaresDisponibles > 0).ToList();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(int usuarioId, int libroId)
        {
            // Validaciones básicas
            var usuario = _db.Usuarios.Find(usuarioId);
            var libro = _db.Libros.Find(libroId);
            if (usuario == null || libro == null)
            {
                ModelState.AddModelError("", "Usuario o libro no encontrados.");
                ViewBag.Usuarios = _db.Usuarios.ToList();
                ViewBag.Libros = _db.Libros.Where(l => l.EjemplaresDisponibles > 0).ToList();
                return View();
            }

            using var tx = _db.Database.BeginTransaction();
            try
            {
                // Releer dentro de la transacción para evitar condiciones de carrera
                libro = _db.Libros.Single(l => l.Id == libroId);
                if (libro.EjemplaresDisponibles <= 0)
                {
                    ModelState.AddModelError("", "No hay ejemplares disponibles para ese libro.");
                    tx.Rollback();
                    ViewBag.Usuarios = _db.Usuarios.ToList();
                    ViewBag.Libros = _db.Libros.Where(l => l.EjemplaresDisponibles > 0).ToList();
                    return View();
                }

                var prestamo = new Prestamo
                {
                    UsuarioId = usuarioId,
                    LibroId = libroId,
                    FechaPrestamo = DateTime.UtcNow,
                    FechaDevolucion = null
                };

                libro.EjemplaresDisponibles -= 1;

                _db.Prestamos.Add(prestamo);
                _db.Libros.Update(libro);
                _db.SaveChanges();

                tx.Commit();
                TempData["Success"] = "Préstamo registrado correctamente.";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                tx.Rollback();
                ModelState.AddModelError("", "Error al procesar el préstamo: " + ex.Message);
                ViewBag.Usuarios = _db.Usuarios.ToList();
                ViewBag.Libros = _db.Libros.Where(l => l.EjemplaresDisponibles > 0).ToList();
                return View();
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Devolver(int prestamoId)
        {
            using var tx = _db.Database.BeginTransaction();
            try
            {
                var prestamo = _db.Prestamos.Include(p => p.Libro).SingleOrDefault(p => p.Id == prestamoId);
                if (prestamo == null) return NotFound();
                if (prestamo.FechaDevolucion != null)
                {
                    TempData["Info"] = "Este préstamo ya fue devuelto.";
                    return RedirectToAction(nameof(Index));
                }

                prestamo.FechaDevolucion = DateTime.UtcNow;
                prestamo.Libro.EjemplaresDisponibles += 1;

                _db.Prestamos.Update(prestamo);
                _db.Libros.Update(prestamo.Libro);
                _db.SaveChanges();

                tx.Commit();
                TempData["Success"] = "Libro devuelto correctamente.";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                tx.Rollback();
                TempData["Error"] = "Error al devolver el libro: " + ex.Message;
                return RedirectToAction(nameof(Index));
            }
        }

}