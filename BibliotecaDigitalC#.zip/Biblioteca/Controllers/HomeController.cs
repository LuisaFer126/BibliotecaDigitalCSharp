using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Biblioteca.Models;
using Biblioteca.Data;
using Microsoft.EntityFrameworkCore;

namespace Biblioteca.Controllers;

public class HomeController : Controller
{
    private readonly BibliotecaContext _db;
    public HomeController(BibliotecaContext db)
    {
        _db = db;
    }

    public IActionResult Index()
    {
        var model = new DashboardViewModel();

        try
        {
            model.TotalUsuarios = _db.Usuarios.Count();
            model.TotalLibros = _db.Libros.Count();
            model.TotalPrestamos = _db.Prestamos.Count();
            model.PrestamosActivos = _db.Prestamos.Count(p => p.FechaDevolucion == null);
        }
        catch
        {
            // Si la BD no está lista, mostrar ceros en vez de fallo.
            model.TotalUsuarios = 0;
            model.TotalLibros = 0;
            model.TotalPrestamos = 0;
            model.PrestamosActivos = 0;
        }

        return View(model);
    }
}
    
